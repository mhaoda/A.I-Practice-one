/*
 * the implementation of the BestFS and the A*.
 */
import java.util.ArrayList;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Queue;

public class Search2 {
	public static void main(String[] args) {
		if (args.length != 2 || loc.getLoc(args[1])==null || map.getMap(args[0])==null) {
			System.out.println("please input the right params");
		}else {
			Search2(map.getMap(args[0]),loc.getLoc(args[1]));
		}
	}
	public static class BestFSnode implements Comparable<BestFSnode>{

		int x,y;
		int length;
		char value;
		public int getX() {
			return x;
		}
		public void setX(int x) {
			this.x = x;
		}
		public int getY() {
			return y;
		}
		public void setY(int y) {
			this.y = y;
		}
		public double getLength() {
			return length;
		}
		public void setLength(int length) {
			this.length = length;
		}
		public char getValue() {
			return value;
		}
		public void setValue(char value) {
			this.value = value;
		}
		public BestFSnode(int x, int y, char value) {
			super();
			this.x = x;
			this.y = y;
			this.value = value;
		}
		@Override
		public String toString() {
			return "" + value  ;
		}
		public BestFSnode() {
			super();
			// TODO Auto-generated constructor stub
		}
		public int compareTo(BestFSnode n) {
			// TODO Auto-generated method stub
			return (int)(length-n.getLength());
		}
		
	}
	public static class AstarNode implements Comparable<AstarNode>{
			int x,y;
			double h;
			double g;
			double f;
			public double getF() {
				return f;
			}
			public void setF(double f) {
				this.f = f;
			}
			public double getG() {
				return g;
			}
			public void setG(double g) {
				this.g = g;
			}
			char value;
			public int getX() {
				return x;
			}
			public void setX(int x) {
				this.x = x;
			}
			public int getY() {
				return y;
			}
			public void setY(int y) {
				this.y = y;
			}
			public double getH() {
				return h;
			}
			public void setH(double h) {
				this.h = h;
			}
			public char getValue() {
				return value;
			}
			public void setValue(char value) {
				this.value = value;
			}
			public AstarNode(int x, int y, char value) {
				super();
				this.x = x;
				this.y = y;
				this.value = value;
			}
			@Override
			public String toString() {
				return "" + value ;
			}
			public AstarNode() {
				super();
				// TODO Auto-generated constructor stub
			}
			@Override
			public int compareTo(AstarNode n) {
				// TODO Auto-generated method stub
				return (int)(f-n.getF());
			}
			
		}
	public static void Search2(int[][] map, int[][] loc) {
		
		//BestFS
		// find the initial state and the goal state.
		BestFSnode start = new BestFSnode();
		BestFSnode goal = new BestFSnode();
		char[] nodeIG = new char[map[0].length];
		for(int m=0;m<map.length;m++) {
			char character = (char)(m+65);
			nodeIG[m] = character;
			for(int n=0;n<map[m].length;n++) {
				if(map[m][n]==2) {
					start.setValue(nodeIG[n]);
					start.setX(loc[n][0]);
					start.setY(loc[n][1]);
				}
				if(map[m][n]==8) {
					goal.setValue(nodeIG[n]);
					goal.setX(loc[n][0]);
					goal.setY(loc[n][1]);
				}
			}
		}
		
		//Initialise the node and put into node list.
		final ArrayList<BestFSnode> nodeList = new ArrayList<BestFSnode>();
		for(int i=0;i<loc.length;i++) {
			BestFSnode n = new BestFSnode(loc[i][0], loc[i][1], (char)(i+65));
			double length1 = 0,length2 = 0;
			double x1,x2,y1,y2;
			x1 = loc[i][0]-goal.x;
			y1 = loc[i][1]-goal.y;
			n.setLength((int)(Math.sqrt(x1*x1+y1*y1)*1000));
			nodeList.add(n);
		}
		
		// initialise the frontier and the explored node list.
		List<BestFSnode> BestFSexploredNode = new ArrayList<BestFSnode>();
		Queue<BestFSnode> BestFSfrontier = new PriorityQueue<BestFSnode>();
		int BestFSmark = 0;
		for(int i=0;i<nodeList.size();i++) {
			if(nodeList.get(i).value==start.value) {
				BestFSmark = i;
			}
		}
		
		// put the initial node into the frontier.
		BestFSfrontier.add(nodeList.get(BestFSmark));
		System.out.println("start: "+ start + "  goal: " + goal);
		System.out.println("=======Best FS Search=======");
		do {
		BestFSnode current = BestFSfrontier.poll();
		char character = current.value;
		
		//get the node that connected to the polled node.
		for(int i=0;i<nodeList.size();i++) {
			if(nodeList.get(i).value== character) {
				BestFSmark = i;
			}
		}
		BestFSexploredNode.add(nodeList.get(BestFSmark));
		
		// judge if the node has been in the frontier explored node list, then put the node into frontier and the explored node list.
		for(int n=0;n<map[BestFSmark].length;n++) {
			if(map[BestFSmark][n]==5) {
				if(!BestFSfrontier.contains(nodeList.get(n))&& !BestFSexploredNode.contains(nodeList.get(n))) {
					BestFSfrontier.offer(nodeList.get(n));
				}
			}
		}
		System.out.println("frontier: " + BestFSfrontier + "  " + "explored: " + BestFSexploredNode);
		
		// if the goal state has been found, stop the loop.
		if(nodeList.get(BestFSmark).value==goal.value) break;
		}while(!BestFSfrontier.isEmpty());
		
		
		//A*
		// find the initial state and the goal state.
		AstarNode AstarStart = new AstarNode();
		AstarNode AstarGoal = new AstarNode();
		char[] AstarNodeIG = new char[map[0].length];
		for(int m=0;m<map.length;m++) {
			char character = (char)(m+65);
			AstarNodeIG[m] = character;
			for(int n=0;n<map[m].length;n++) {
				if(map[m][n]==2) {
					AstarStart.setValue(AstarNodeIG[n]);
					AstarStart.setX(loc[n][0]);
					AstarStart.setY(loc[n][1]);
				}
				if(map[m][n]==8) {
					AstarGoal.setValue(AstarNodeIG[n]);
					AstarGoal.setX(loc[n][0]);
					AstarGoal.setY(loc[n][1]);
				}
			}
		}
		
		//Initialise the node and put into node list.
		final ArrayList<AstarNode> AstarNodeList = new ArrayList<AstarNode>();
		for(int i=0;i<loc.length;i++) {
			AstarNode n = new AstarNode(loc[i][0], loc[i][1], (char)(i+65));
			double length1 = 0,length2 = 0;
			double x1,x2,y1,y2;
			x1 = loc[i][0]-AstarGoal.x;
			y1 = loc[i][1]-AstarGoal.y;
			n.setH((int)(Math.sqrt(x1*x1+y1*y1)));
			AstarNodeList.add(n);
		}
		
		// initialise the frontier and the explored node list.
		Queue<AstarNode> AstarFrontier = new PriorityQueue<AstarNode>();
		List<AstarNode> AstarExploredNode = new ArrayList<AstarNode>();
		int AstarMark = 0;
		for(int i=0;i<AstarNodeList.size();i++) {
			if(AstarNodeList.get(i).value==AstarStart.value) {
				AstarMark = i;
			}
		}
		
		// put the initial node into the frontier.
		AstarFrontier.add(AstarStart);
		System.out.println("start: " + AstarStart + "  goal: " + AstarGoal);
		System.out.println("=======A* Search=======");
		do {
			AstarNode current = new AstarNode();
			current = AstarFrontier.poll();
			char character = current.value;
			
			//get the node that connected to the polled node.
			for (int i = 0; i < AstarNodeList.size(); i++) {
				if (AstarNodeList.get(i).value == character) {
					AstarMark = i;
				}
			}
			AstarExploredNode.add(AstarNodeList.get(AstarMark));
			
			//figure out the g.
			double g = 0;
			if (AstarExploredNode.size() >= 2
					&& AstarExploredNode.get(AstarExploredNode.size() - 1).value != AstarGoal.value) {
				int mark1 = 0, mark2 = 0;
				AstarNode n1 = AstarExploredNode.get(AstarExploredNode.size() - 1);
				AstarNode n2 = AstarExploredNode.get(AstarExploredNode.size() - 2);
				for (int i = 0; i < AstarNodeList.size(); i++) {
					if (AstarNodeList.get(i).value == n1.getValue()) {
						mark1 = i;
					}
					if (AstarNodeList.get(i).value == n2.getValue()) {
						mark2 = i;
					}
				}
				double x1, x2, y1, y2;
				x1 = loc[mark1][0] - loc[mark2][0];
				y1 = loc[mark1][1] - loc[mark2][1];
				g = Math.sqrt(x1 * x1 + y1 * y1);
				AstarNodeList.get(mark1).setG(g);
			}
			
			// judge if the node has been in the frontier explored node list, then put the node into frontier and the explored node list.
			for (int n = 0; n < map[AstarMark].length; n++) {
				if (map[AstarMark][n] == 5) {
					if (!AstarFrontier.contains(AstarNodeList.get(n))
							&& !AstarExploredNode.contains(AstarNodeList.get(n))) {
						AstarNodeList.get(n).setF(AstarNodeList.get(n).h + g);
						AstarFrontier.offer(AstarNodeList.get(n));
					}
				}
			}
			System.out.println("frontier: " + AstarFrontier + "  " + "explored: " + AstarExploredNode);
			
			// if the goal state has been found, stop the loop.
			if (AstarNodeList.get(AstarMark).value == AstarGoal.value)break;
		} while (!AstarFrontier.isEmpty());
		
		//print out the solution.
		if (BestFSfrontier.isEmpty() && !BestFSexploredNode.contains(goal)) {
			System.out.println("===================");
			System.out.println("No solution!");
		} else {
			System.out.println("======Best FS Solution======");
			System.out.println(BestFSexploredNode);
		}
		if (AstarFrontier.isEmpty() && !AstarExploredNode.contains(AstarGoal)) {
			System.out.println("===================");
			System.out.println("No solution!");
		} else {
			System.out.println("======A* Solution======");
			System.out.println(AstarExploredNode);
		}

	}
}
