/*
 * the implementation of the BFS and DFS.
 */
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Stack;

public class Search1 {
	public static void main(String[] args) {
		if (args.length != 1 || map.getMap(args[0])==null) {
			System.out.println("please input the right param");
		}else {
			Search1(map.getMap(args[0]));
		}
	}
	
	public static void Search1(int[][] map) {
		
		// initialise all nodes and, find the initial state and the goal state.
		char start = 0, goal = 0;
		char[] nodeList = new char[map[0].length];
		for(int m=0;m<map.length;m++) {
			char character = (char)(m+65);
			nodeList[m] = character;
			for(int n=0;n<map[m].length;n++) {
				
				if(map[m][n]==2) {
					start = nodeList[n];
				}
				if(map[m][n]==8) {
					goal = nodeList[n];
				}
			}
		}
		
		//BFS
		// initialise the frontier and the explored node list.
		Queue<Character> BFSfrontier = new LinkedList<Character>();
		List<Character> BFSexploredNode = new ArrayList<Character>();
		
		// put the initial node into the frontier.
		BFSfrontier.offer(start);
		System.out.println("start: "+ start + "  goal: " + goal);
		System.out.println("=======BFS Search=======");
		int BFSmark = 0;

		do{
		char character = BFSfrontier.poll();
		
		//get the node that connected to the polled node.
		for(int i = 0;i<nodeList.length;i++){
			if(nodeList[i]==character){
				BFSmark=i;
			}
		}
		
		// judge if the node has been in the frontier explored node list, then put the node into frontier and the explored node list.
		for(int n=0;n<map[BFSmark].length;n++){
			if(map[BFSmark][n]==5){
				if(!BFSexploredNode.contains(nodeList[n])&&!BFSfrontier.contains(nodeList[n])){
				BFSfrontier.add(nodeList[n]);
				}
			}
		}
		BFSexploredNode.add(nodeList[BFSmark]);
		System.out.println("frontier "+BFSfrontier+ "  explored"+BFSexploredNode);
		
		// if the goal state has been found, stop the loop.
		if(goal == nodeList[BFSmark]) break;
		}while(!BFSfrontier.isEmpty());
	
		
		//DFS
		// initialise the frontier and the explored node list.
		Stack<Character> DFSfrontier = new Stack<Character>();
		List<Character> DFSexploredNode = new ArrayList<Character>();
		
		// put the initial node into the frontier.
		DFSfrontier.add(start);
		System.out.println("start: "+ start + "  goal: " + goal);
		System.out.println("=======DFS Search=======");
		int DFSmark=0;
		do{
		char character = DFSfrontier.pop();
		
		//get the node that connected to the polled node.
		for(int i = 0;i<nodeList.length;i++){
			if(nodeList[i]==character){
				DFSmark=i;
			}
		}
		
		// judge if the node has been in the frontier explored node list, then put the node into frontier and the explored node list.
		for(int n=0;n<map[DFSmark].length;n++){
			if(map[DFSmark][n]==5){
				if(!DFSexploredNode.contains(nodeList[n])&&!DFSfrontier.contains(nodeList[n])){
				DFSfrontier.add(nodeList[n]);
				}
			}
		}
		DFSexploredNode.add(nodeList[DFSmark]);
		System.out.println("frontier "+DFSfrontier+ "  explored"+DFSexploredNode);
		
		// if the goal state has been found, stop the loop.
		if(goal == nodeList[DFSmark]) break;
		}while(!DFSfrontier.isEmpty());
		
		//print out the solution.
		if(BFSfrontier.isEmpty()&&!BFSexploredNode.contains(goal)) {
			System.out.println("===================");
			System.out.println("No solution!");
		}else {
		System.out.println("======BFS Solution======");
		System.out.println(BFSexploredNode);
		}
		if(DFSfrontier.isEmpty()&&!DFSexploredNode.contains(goal)) {
			System.out.println("===================");
			System.out.println("No solution!");
		}else {
		System.out.println("======DFS Solution======");
		System.out.println(DFSexploredNode);
		}
		
	}
}
