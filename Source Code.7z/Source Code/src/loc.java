/*
 * loc
 */
public class loc {
	public static int[][] loc1 = new int[][] { { 0, 2 }, { 2, 0 }, { 4, 3 }, { 7, 0 }, { 2, 4 }, { 0, 6 }, { 0, 9 },
			{ 2, 7 }, { 5, 8 }, { 5, 5 }, { 2, 9 }, { 7, 4 }, { 8, 7 }, { 9, 9 }, { 9, 4 }, };

	public static int[][] loc2 = new int[][] { { 0, 2 }, { 2, 0 }, { 4, 3 }, { 7, 0 }, { 2, 4 }, { 0, 6 }, { 0, 9 },
			{ 2, 7 }, { 5, 8 }, { 5, 5 }, { 2, 9 }, { 7, 4 }, { 8, 7 }, { 9, 9 }, { 9, 4 }, };

	public static int[][] loc3 = new int[][] { { 0, 2 }, { 2, 0 }, { 4, 3 }, { 7, 0 }, { 2, 4 }, { 0, 6 }, { 0, 9 },
			{ 2, 7 }, { 5, 8 }, { 5, 5 }, { 2, 9 }, { 7, 4 }, { 8, 7 }, { 9, 9 }, { 9, 4 }, };

	public static int[][] loc4 = new int[][] { { 0, 2 }, { 2, 0 }, { 4, 3 }, { 7, 0 }, { 2, 4 }, { 0, 6 }, { 0, 9 },
			{ 2, 7 }, { 5, 8 }, { 5, 5 }, { 2, 9 }, { 7, 4 }, { 8, 7 }, { 9, 9 }, { 9, 4 }, };
	public static int[][] loc5 = new int[][] { { 0, 2 }, { 2, 0 }, { 4, 3 }, { 7, 0 }, { 2, 4 }, { 0, 6 }, { 0, 9 },
			{ 2, 7 }, { 5, 8 }, { 5, 5 }, { 2, 9 }, { 7, 4 }, { 8, 7 }, { 9, 9 }, { 9, 4 }, };

	public static int[][] loc6 = new int[][] { { 0, 0 }, { 5, 3 }, { 8, 5 }, { 9, 9 }, { 2, 5 }, { 4, 7 }, { 6, 8 }, };

	public static int[][] loc7 = new int[][] { { 0, 0 }, { 5, 3 }, { 8, 5 }, { 9, 9 }, { 2, 5 }, { 4, 7 }, { 6, 8 }, };

	public static int[][] loc8 = new int[][] { { 0, 0 }, { 3, 0 }, { 6, 0 }, { 9, 0 }, { 0, 3 }, { 3, 3 }, { 6, 3 },
			{ 9, 3 }, { 0, 6 }, { 3, 6 }, { 6, 6 }, { 9, 6 }, { 0, 9 }, { 3, 9 }, { 6, 9 }, { 9, 9 }, };
	public static int[][] loc9 = new int[][] { { 0, 0 }, { 3, 0 }, { 6, 0 }, { 9, 0 }, { 0, 3 }, { 3, 3 }, { 6, 3 },
			{ 9, 3 }, { 0, 6 }, { 3, 6 }, { 6, 6 }, { 9, 6 }, { 0, 9 }, { 3, 9 }, { 6, 9 }, { 9, 9 }, };

	public static int[][] getLoc(String i) {

		if (i.equals("loc1")) {
			return loc1;
		}
		if (i.equals("loc2")) {
			return loc2;
		}
		if (i.equals("loc3")) {
			return loc3;
		}
		if (i.equals("loc4")) {
			return loc4;
		}
		if (i.equals("loc5")) {
			return loc5;
		}
		if (i.equals("loc6")) {
			return loc6;
		}
		if (i.equals("loc7")) {
			return loc7;
		}
		if (i.equals("loc8")) {
			return loc8;
		}
		if (i.equals("loc9")) {
			return loc9;
		} else {
			return null;
		}
	}
}
